#########################################
# NOTCH FILTER PROJECT 					#
#										#
# Written by Timothy Wong and Tack Lee	#	
# ver1.0	Last revised: 3/13/2018 	#
#########################################

import serial
import time
import nf_header

########################
#					   #
# Serial COM functions #
#					   #
########################

def comOpen(port):
	# initiate serial communication
	ser = serial.Serial()
	ser.baudrate = 38400
	ser.port = port	# depends on driver installation
	ser.timeout = 3
	ser.open()
	if (ser.is_open): print("Serial connection established.")
	return ser

def comClose(ser):
	ser.close()
	print("Serial connection closed.")
	
	
#####################
#					#
# Protocol commands #
#					#
#####################

def reset(ser):	# RESET
	# prepare packet as a byte array and send through COM
	packet = nf_header.reset()
	ser.write(packet)
	
	# read and print response from COM
	nf_header.reset_resp(ser)
	
def getVersion(ser):	# GET VERSION INFORMATION
	# prepare packet as a byte array and send through COM
	packet = nf_header.getVersion()
	ser.write(packet)
	print("Sent packet: ", packet)
	
	# read and print response from COM
	# response has 34 bytes
	nf_header.getVersion_resp(ser)
	
def getSystemStats(ser):	# GET SYSTEM STATUS
	# prepare packet as a byte array and send through COM
	packet = nf_header.getSystemStats()
	ser.write(packet)
	print("Sent packet: ", packet)
	
	# read and print response from COM
	# response has 24 bytes
	nf_header.getSystemStatus_resp(ser)
	
def setSystemConfig(ser):	# SET SYSTEM CONFIGURATION
	# prepare packet as a byte array and send through COM
	packet = nf_header.setSystemConfig()
	ser.write(packet)
	print("Sent packet: ", packet)
	
	# read and print response from COM
	# response has 24 bytes
	nf_header.getSystemStatus_resp(ser)

def setDefaultConfig(ser):	# SET DEFAULT CONFIGURATION
	# this cmd will enable ALC_OnOff, which will turn on the Alarm LED
	# send cmd 4 to disable ALC_OnOff for normal operation

	# prepare packet as a byte array and send through COM
	packet = nf_header.setDefaultConfig()
	ser.write(packet)
	print("Sent packet: ", packet)
	
	# read and print response from COM
	# response has 24 bytes
	nf_header.getSystemStatus_resp(ser)	

def setFilterConfig(ser):	# SET DIGITAL FILTER CONFIGURATION
	# prepare packet as a byte array and send through COM
	packet = nf_header.setFilterConfig()
	ser.write(packet)
	print("Sent packet: ", packet)
	
	# read and print response from COM
	# response has 86 bytes
	# (1+4+4+1) bytes per channel * 8 channels + 6 bytes from header, etc. 
	nf_header.getFilterConfig_resp(ser)	
	
def getFilterConfig(ser):	# GET DIGITAL FILTER CONFIGURATION
	# prepare packet as a byte array and send through COM
	packet = nf_header.getFilterConfig()
	ser.write(packet)
	print("Sent packet: ", packet)
	
	# read and print response from COM
	# response has 86 bytes
	# (1+4+4+1) bytes per channel * 8 channels + 6 bytes from header, etc. 
	nf_header.getFilterConfig_resp(ser)	
	
#-----------------------------------------------#	
# ACR Commands (not used for automated testing)	#
#-----------------------------------------------#

def setACRConfig(ser):	# SET ACR CONFIGURATION
	# prepare packet as a byte array and send through COM
	packet = nf_header.setACRConfig()
	ser.write(packet)
	print("Sent packet: ", packet)
	
	# read and print response from COM
	# response has 687 bytes
	# each ACR line has {ACR_OnOff (1), ACR_LeadTime (4), Ch1~8 params ((1+4+4+1)*8)} -> 85 bytes
	# total bytes = 85 bytes per ACR line * 8 ACR lines + (1 byte extra) + 6 bytes from preamble, etc. = 687 bytes
	nf_header.getACRConfig_resp(ser)
	
def getACRConfig(ser):	# GET ACR CONFIGURATION
	# prepare packet as a byte array and send through COM
	packet = nf_header.getACRConfig()
	ser.write(packet)
	print("Sent packet: ", packet)
	
	# read and print response from COM
	# response has 687 bytes
	# each ACR line has {ACR_OnOff (1), ACR_LeadTime (4), Ch1~8 params ((1+4+4+1)*8)} -> 85 bytes
	# total bytes = 85 bytes per ACR line * 8 ACR lines + (1 byte extra) + 6 bytes from preamble, etc. = 687 bytes
	nf_header.getACRConfig_resp(ser)
	
	
##############################################
#											 #
# Special functions (for HD data test cases) #
#											 #
##############################################

# for TC 1 - Handover: FM1 -> FM2
def setFilterConfig_handover(ser):
	print("Sending command: Set digital filter configuration for HD handover test case...")
	for atten in range(0, 30):
		print("+++ atten = ", atten, " +++")
		packet = nf_header.setFilterConfig_handover(atten, atten, atten, atten, 30-atten, 30-atten, 30-atten, 30-atten)
		ser.write(packet)
	
		nf_header.getFilterConfig_resp(ser)
		time.sleep(3)