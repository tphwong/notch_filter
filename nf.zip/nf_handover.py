import serial
import time
import nf, nf_header

# specify which COM port to open
com = nf.comOpen('COM32')

nf.setFilterConfig_handover(com)

nf.comClose(com)